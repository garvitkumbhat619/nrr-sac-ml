nrr_kaggle_bundle.zip - input dataset for UMA_Kaggle.ipynb
  SAC_broadened_package/   280 new catalysts (N/C divacancy, single vacancy), 3,961 structure files
  SAC_UMA_package/         196 Xu S/N catalysts, 2,782 structure files
  previous/results_omat_SN.jsonl   your Colab UMA (omat) results for the S/N set, so finished work is skipped
  kaggle_worker.py, nrr_mlip.py, sac_builder.py, validate.py   code
