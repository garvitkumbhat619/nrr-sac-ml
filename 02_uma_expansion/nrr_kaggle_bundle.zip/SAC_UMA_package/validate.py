"""Compare MLIP results with Xu et al. 2025 DFT (PBE-D3) and fit a linear calibration."""
import numpy as np, pandas as pd
import matplotlib.pyplot as plt

PAIRS = [  # (MLIP column, Xu column, label)
    ('dE_N2_end',  'xu_dE_N2_end',  'ΔE *N2 end-on'),
    ('dE_N2_side', 'xu_dE_N2_side', 'ΔE *N2 side-on'),
    ('dE_NNH_end', 'xu_dE_NNH_end', 'ΔE *NNH end-on'),
    ('dE_NNH_side','xu_dE_NNH_side','ΔE *NNH side-on'),
    ('dE_NH2',     'xu_dE_NH2',     'ΔE *NH2'),
    ('dG_H*',      'xu_dG_H',       'ΔG *H'),
    ('Ef_eV',      'xu_Ef_PBE_eV',  'Ef (vs bulk, PBE)'),
]


def add_udiss(sac_df, ref):
    """U_diss = U0_diss - Ef / n_e  (Greeley & Norskov), using the MLIP Ef."""
    m = sac_df.merge(ref[['SAC', 'U0_diss_V', 'n_e']], on='SAC', how='left')
    m['U_diss_V'] = m.U0_diss_V - m.Ef_eV / m.n_e
    m['stable_stage1'] = ((m.Ef_eV < 0) & (m.U_diss_V > 0)).astype(int)
    return m


def compare(sac_df, ref, only_ok=True):
    m = sac_df.merge(ref, on='SAC', how='inner')
    if only_ok and 'status_bare' in m:
        m = m[m.status_bare == 'ok']
    out = []
    for a, b, lab in PAIRS:
        if a not in m or b not in m:
            continue
        d = m[[a, b]].copy()
        st = {'dG_H*': 'status_H'}.get(a, a.replace('dE_', 'status_') if a.startswith('dE_') else None)
        if only_ok and st in m:
            d = d[m[st] == 'ok']
        d = d.dropna()
        if len(d) < 3:
            continue
        err = d[a] - d[b]
        k, c = np.polyfit(d[a], d[b], 1)
        r = np.corrcoef(d[a], d[b])[0, 1]
        out.append(dict(quantity=lab, mlip=a, xu=b, n=len(d), MAE=err.abs().mean(), mean_shift=err.mean(),
                        r=r, MAE_after_linear_fit=(d[b] - (k * d[a] + c)).abs().mean(), slope=k, intercept=c))
    return pd.DataFrame(out)


def parity(sac_df, ref, title='', path=None):
    m = sac_df.merge(ref, on='SAC', how='inner')
    pairs = [p for p in PAIRS if p[0] in m and m[[p[0], p[1]]].dropna().shape[0] >= 3]
    n = len(pairs)
    if n == 0:
        return
    fig, ax = plt.subplots(1, n, figsize=(3.2 * n, 3.3))
    ax = np.atleast_1d(ax)
    for x, (a, b, lab) in zip(ax, pairs):
        d = m[[a, b]].dropna()
        x.scatter(d[b], d[a], s=18, alpha=.8)
        lo, hi = np.nanmin(d.values) - .3, np.nanmax(d.values) + .3
        x.plot([lo, hi], [lo, hi], 'k--', lw=.8)
        x.set_xlim(lo, hi); x.set_ylim(lo, hi)
        x.set_title(f'{lab}\nMAE {np.abs(d[a]-d[b]).mean():.2f} eV, n={len(d)}', fontsize=9)
        x.set_xlabel('Xu DFT (eV)'); x.set_ylabel('MLIP (eV)')
    fig.suptitle(title); fig.tight_layout()
    if path:
        fig.savefig(path, dpi=150)
    return fig


def calibrate(sac_df, table):
    """Apply Xu = slope*MLIP + intercept for every quantity in `table` -> new *_cal columns."""
    s = sac_df.copy()
    for _, r in table.iterrows():
        if r.mlip in s:
            s[r.mlip + '_cal'] = r.slope * s[r.mlip] + r.intercept
    return s
