# SAC_UMA_package: input structures and workflow for MLIP (UMA) NRR calculations

These are starting structures for the 196 TM@SxNy-graphene single-atom catalysts of Xu et al. (Nano Research 2025).
They cover 28 metals × 7 supports and come with every NRR/HER intermediate. The package also contains the code that turns
MLIP energies into ΔE, ΔG, U_L, ΔG*H, Ef and U_diss.

No public coordinate files exist for these catalysts. Xu et al. only offer data "on request", and the NIMS CSACD and
LOCAL databases do not include them. The structures were therefore **built from the paper's description**:

* 5×5×1 graphene with two adjacent C atoms removed.
* The 4 dangling C atoms are replaced by S/N.
* About 15 Å of vacuum (cell c = 20 Å).
* The structures were then **pre-relaxed with MACE-MPA-0**, so UMA starts from a sensible geometry.

## Folder layout

```
structures/<TM@support>/bare.vasp      the catalyst            (49 atoms)
                        H.vasp         *H                      (HER)
                        N2_end.vasp    *N2 end-on
                        N2_side.vasp   *N2 side-on
                        NNH_end.vasp   *N-NH  (distal / alternating start)
                        NNH_side.vasp  *NNH side-on
                        NNH2.vasp      *N-NH2 (distal)
                        N.vasp, NH.vasp, NH2.vasp, NH3.vasp
                        NHNH.vasp, NHNH2.vasp, NH2NH2.vasp  (alternating)
supports/<support>.vasp                metal-free support (for Ef)
bulk/<metal>.vasp                      bulk metal (for Ef; α-Mn has 29 atoms)
gas/N2.vasp, H2.vasp, NH3.vasp         gas molecules in a box
manifest.csv                           every file with its tier
xu_reference.csv                       Xu DFT values (ΔE, ΔG, Ebin, Ef, U_diss) for validation
sac_builder.py                         how the structures were built (re-run to change anything)
nrr_mlip.py                            relax + analyse (works with any ASE calculator)
validate.py                            comparison with Xu DFT, parity plots, linear calibration
UMA_NRR_Colab.ipynb                    the notebook to run
```

Supports and S positions are labelled around the divacancy: a1/a2 are the neighbours of one removed C, and b1/b2 of the other.

| support | S on | note |
|---|---|---|
| N4 | – | |
| S1N3 | a1 | |
| S2N2-PEN | a1, b1 | the two S lie in the same 5-ring with the metal |
| S2N2-HEX | a1, a2 | the two S lie in the same 6-ring with the metal |
| S2N2-OPP | a1, b2 | the two S are opposite each other |
| S3N1 | a1, a2, b1 | |
| S4 | all | |

In every file the metal is the last atom of the catalyst and adsorbate atoms come after it. The metal always points to +z, and adsorbates sit on top of it.

`.vasp` files are VASP POSCARs. Open them in **VESTA** (free) or in Python (`ase.io.read`). They can also be used directly for
real DFT later, for example to check the best catalysts with VASP or Quantum ESPRESSO.

## Tiers (`manifest.csv`)

| tier | what | why |
|---|---|---|
| 0_reference | gases, 7 supports, 28 bulk metals | needed for every energy |
| 1_validation | 23 SACs × all intermediates | compare with Xu DFT before trusting the model |
| 2_screening | all 196 SACs: bare, *H, *N2 end/side, *NNH end/side, *NH2, *NH3 | Xu's descriptors, ΔG*H and Ef for all 196 |
| 3_full_pathway | the remaining intermediates | full distal and alternating U_L |

Xu et al. computed activity for only 91 of the 196 SACs. This run fills in the other 105.

## How to run (Google Colab, free T4 GPU)

1. Request access to UMA at https://huggingface.co/facebook/UMA, then make a *Read* token at https://huggingface.co/settings/tokens.
2. In Google Drive, create the folder `My Drive/NRR_UMA` and upload `SAC_UMA_package.zip` into it.
3. Open `UMA_NRR_Colab.ipynb` in Colab (File → Upload notebook).
4. Set the runtime to T4 GPU and add the token as a Colab secret named `HF_TOKEN`.
5. Run the cells from top to bottom. Results are written to Drive after every structure. If Colab disconnects, re-run
   steps 1–5 and continue; finished structures are skipped.
6. Send back `UMA_SAC_results_*.csv`, `UMA_structure_energies_*.csv` and `parity_*.png`.

To test without a login, set `MODEL = 'mace'` in step 2 and `TEST_MODE = True` in step 6.

## Conventions used in the analysis

These match Xu et al. 2025 where possible.

* ΔE(*NxHy) = E(*NxHy) − E(*) − x/2·E(N2) − y/2·E(H2), as in Xu's Eq. 3.
* ΔG = ΔE + ΔZPE − TΔS at 298 K. The adsorbate ZPE and TS come from a harmonic finite-difference calculation with the
  same MLIP, with modes below 50 cm⁻¹ raised to 50 cm⁻¹. Gas values are the standard CHE ones: H2 0.27/0.40,
  N2 0.15/0.59 and NH3 0.89/0.60 eV.
* NH3(g) is anchored to experiment: ½N2 + 3/2H2 → NH3 has ΔG = −0.17 eV. This removes the GGA error of the N≡N bond.
* U_L = −max(ΔG) over the proton–electron steps only. N2 adsorption and the final NH3 release are excluded.
* Ef = E(TM@support) − E(support) − E(bulk metal)/atom, and U_diss = U°diss − Ef/n_e (Greeley & Nørskov).
* The bare-SAC energy is the lower of (a) the relaxed bare structure and (b) the structure obtained by removing H from the
  relaxed *H and re-relaxing. This guards against a bare SAC stuck in a higher-energy shape.
* Every adsorbate is checked after relaxation: it must still be on the metal, H must not jump to S/N/C, and N–N must stay bonded.
  Flagged structures are excluded from the validation statistics.

## Pipeline test (done before shipping)

The whole workflow was run end to end with MACE-MPA-0, because UMA cannot be downloaded in the build environment. The run
covered the 23 validation SACs, the full pathway for Mo@N4, Mo@S3N1 and W@S3N1, all references, and the notebook itself in
`TEST_MODE`.

* The code works.
* MACE's zero-shot agreement with Xu's DFT is poor: MAE 0.44–0.95 eV on ΔE and r ≤ 0.7. This is the bar UMA has to beat.
* The strip-and-re-relax check found a lower bare geometry, by 0.36–0.60 eV, for Ta@S1N3, Ta@S3N1, W@S3N1 and Zr@S2N2-HEX.
  Without it, every ΔE of those SACs would have been wrong.
* 20 of the 196 bare SACs (mostly Cd, Hg, Zn, Ag, Au and Y on S-rich supports, plus W@S1N3, W@S2N2-OPP and Mn@S3N1) are
  shipped as built rather than pre-relaxed. This is because MACE pushed the metal out of the N/S site. See `start_geometry`
  in `manifest.csv`.

## Known limitations

* UMA `oc20` is trained on RPBE and `omat` on PBE. Xu used PBE-D3 with VASPsol checks, so systematic offsets are expected.
  The notebook measures them on the validation set and reports a linear calibration.
* The structures are not DFT-relaxed. If a result matters for the thesis conclusions (for example the top 5 catalysts),
  confirm it with DFT, using these POSCARs as the start.
* Spin is not handled explicitly by `oc20`/`omat` (they learn the spin-polarised DFT energy implicitly).
