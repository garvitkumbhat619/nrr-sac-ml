"""
sac_builder.py  -  builds TM@SxNy-graphene single-atom catalysts and NRR/HER
intermediates, following Xu et al., Nano Research 2025 (Section 3.1.1):

  "a 5 x 5 x 1 graphene supercell is employed as the substrate, where two
   adjacent C atoms are removed ... then the coordinated C atoms are replaced
   with S and N atoms."  Vacuum 15 A.

Geometry of the divacancy (looking down z):

        a1 ------ b1          i, j = the two removed C atoms
         \\       /           a1, a2 = old neighbours of i
     a2 - (i)--(j) - b2       b1, b2 = old neighbours of j
                              a1,b1 lie on the same side (+v) of the i-j axis

  TM-a1-...-b1  closes a 5-ring  (pentagon)
  TM-a1-...-a2  closes a 6-ring  (hexagon)

Seven supports (S positions):
  N4          -
  S1N3        a1
  S2N2-PEN    a1, b1    (two S in the same pentagon)
  S2N2-HEX    a1, a2    (two S in the same hexagon)
  S2N2-OPP    a1, b2    (S opposite each other)
  S3N1        a1, a2, b1
  S4          a1, a2, b1, b2

Adsorbates are placed on the +z side, on top of the metal.
Broadened families (added later): FAMILY_A = N/C mixtures on the divacancy,
FAMILY_C = 3-coordinate single-vacancy sites (see SPECS).
"""
import numpy as np
from ase import Atoms
from ase.build import graphene, bulk
from ase.spacegroup import crystal
from ase.geometry import get_distances

SUPPORTS = {          # Xu 2025 S/N family: which divacancy sites carry S (the rest are N)
    'N4':       [],
    'S1N3':     ['a1'],
    'S2N2-PEN': ['a1', 'b1'],
    'S2N2-HEX': ['a1', 'a2'],
    'S2N2-OPP': ['a1', 'b2'],
    'S3N1':     ['a1', 'a2', 'b1'],
    'S4':       ['a1', 'a2', 'b1', 'b2'],
}
# Every support as (vacancy type, element on each coordinating site).
# DV = divacancy, sites a1 a2 b1 b2 (as above).  SV = single vacancy, sites n1 n2 n3.
# A "C" site is simply the original dangling carbon left in place.
SPECS = {name: ('DV', {k: ('S' if k in v else 'N') for k in ('a1', 'a2', 'b1', 'b2')})
         for name, v in SUPPORTS.items()}
_dv = lambda C: ('DV', {k: ('C' if k in C else 'N') for k in ('a1', 'a2', 'b1', 'b2')})
_sv = lambda C: ('SV', {k: ('C' if k in C else 'N') for k in ('n1', 'n2', 'n3')})
FAMILY_A = {                         # mixed N/C on the divacancy (4-coordinate)
    'N3C1':     _dv(['a1']),
    'N2C2-PEN': _dv(['a1', 'b1']),
    'N2C2-HEX': _dv(['a1', 'a2']),
    'N2C2-OPP': _dv(['a1', 'b2']),
    'N1C3':     _dv(['a1', 'a2', 'b1']),
    'C4':       _dv(['a1', 'a2', 'b1', 'b2']),
}
FAMILY_C = {                         # single vacancy (3-coordinate)
    'SV-N3':   _sv([]),
    'SV-N2C1': _sv(['n1']),
    'SV-N1C2': _sv(['n1', 'n2']),
    'SV-C3':   _sv(['n1', 'n2', 'n3']),
}
SPECS.update(FAMILY_A); SPECS.update(FAMILY_C)
METALS = ['Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
          'Y', 'Zr', 'Nb', 'Mo', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd',
          'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg']
CELL_Z = 20.0          # ~15 A of vacuum above/below the sheet + room for adsorbates


def _sheet():
    g = graphene(formula='C2', a=2.46, size=(5, 5, 1), vacuum=CELL_Z / 2)
    g.pbc = True
    pos = g.get_positions()
    d = np.linalg.norm(pos[:, :2] - pos.mean(axis=0)[:2], axis=1)
    D = g.get_all_distances(mic=True)
    nb = lambda k: [m for m in range(len(g)) if 1.3 < D[k, m] < 1.5]
    return g, d, nb


def _divacancy_sheet():
    """5x5 graphene, the 2 C to remove and the 4 coordinating C labelled a1,a2,b1,b2."""
    g, d, nb = _sheet()
    i = int(np.argmin(d))
    j = min(nb(i), key=lambda k: d[k])
    u = g.get_distance(i, j, mic=True, vector=True); u /= np.linalg.norm(u)
    v = np.cross([0, 0, 1], u)
    side = lambda k: np.dot(g.get_distance(i, k, mic=True, vector=True), v)
    a1, a2 = sorted([k for k in nb(i) if k != j], key=side, reverse=True)
    b1, b2 = sorted([k for k in nb(j) if k != i], key=side, reverse=True)
    return g, [i, j], dict(a1=a1, a2=a2, b1=b1, b2=b2)


def _single_vacancy_sheet():
    """5x5 graphene, the C to remove and its 3 neighbours n1,n2,n3."""
    g, d, nb = _sheet()
    i = int(np.argmin(d))
    ang = lambda k: np.arctan2(*g.get_distance(i, k, mic=True, vector=True)[[1, 0]])
    n1, n2, n3 = sorted(nb(i), key=ang)
    return g, [i], dict(n1=n1, n2=n2, n3=n3)


def build_support(support, metal=None, rng=None):
    """Defective support (metal=None) or the SAC TM@support.
    S atoms and the metal start above the plane, because C-S (~1.75 A) and
    TM-S (~2.3 A) bonds do not fit in a flat divacancy; in a single vacancy the
    hole is too small for any metal, so it starts ~1.3 A above the sheet."""
    rng = rng or np.random.default_rng(0)
    vac, elem = SPECS[support]
    g, removed, lab = _divacancy_sheet() if vac == 'DV' else _single_vacancy_sheet()
    centre = g.positions[removed].mean(axis=0)
    sym = g.get_chemical_symbols()
    for k, idx in lab.items():
        sym[idx] = elem[k]
    g.set_chemical_symbols(sym)
    s_sites = [idx for k, idx in lab.items() if elem[k] == 'S']
    for k in s_sites:                               # push S outward and up
        r = g.positions[k] - centre; r[2] = 0
        g.positions[k] += 0.25 * r / np.linalg.norm(r) + [0, 0, 0.45]
    g = g[[k for k in range(len(g)) if k not in removed]]
    if metal is not None:
        z_tm = [0.0, 0.6, 0.9, 1.1, 1.3][len(s_sites)] if vac == 'DV' else 1.3
        g += Atoms(metal, positions=[centre + [0, 0, z_tm]])
    g.positions += rng.normal(0, 0.02, g.positions.shape)   # break symmetry
    g.wrap()
    return g


def orient(a, n_sub=None):
    """Put the metal on the +z side of the sheet (mirror if needed). The metal is the
    last substrate atom (index n_sub-1)."""
    a = a.copy()
    tm = (n_sub or len(a)) - 1
    z0 = np.median(a.positions[:tm, 2])
    if a.positions[tm, 2] < z0 - 0.05:
        a.positions[:, 2] = 2 * z0 - a.positions[:, 2]
    a.wrap()
    return a


# ---------- adsorbates: positions relative to the metal (x along cell a) ----
ADSORBATES = {
    'H':       [('H', (0, 0, 1.65))],
    'N2_end':  [('N', (0, 0, 1.95)), ('N', (0, 0, 3.08))],
    'N2_side': [('N', (-0.56, 0, 2.05)), ('N', (0.56, 0, 2.05))],
    'NNH_end': [('N', (0, 0, 1.85)), ('N', (0.20, 0, 3.05)), ('H', (1.15, 0, 3.45))],
    'NNH_side':[('N', (-0.62, 0, 2.00)), ('N', (0.62, 0, 2.00)), ('H', (1.30, 0, 2.75))],
    'NNH2':    [('N', (0, 0, 1.80)), ('N', (0, 0, 3.08)), ('H', (0.88, 0, 3.60)), ('H', (-0.88, 0, 3.60))],
    'N':       [('N', (0, 0, 1.70))],
    'NH':      [('N', (0, 0, 1.75)), ('H', (0, 0, 2.78))],
    'NH2':     [('N', (0, 0, 1.90)), ('H', (0.81, 0, 2.48)), ('H', (-0.81, 0, 2.48))],
    'NH3':     [('N', (0, 0, 2.15)), ('H', (0.94, 0, 2.50)), ('H', (-0.47, 0.814, 2.50)), ('H', (-0.47, -0.814, 2.50))],
    # alternating / enzymatic branch (end-on)
    'NHNH':    [('N', (0, 0, 1.85)), ('H', (-0.95, 0, 2.25)), ('N', (0.25, 0, 3.10)), ('H', (1.20, 0, 3.45))],
    'NHNH2':   [('N', (0, 0, 1.90)), ('H', (-0.95, 0, 2.30)), ('N', (0.15, 0, 3.33)),
                ('H', (1.08, 0, 3.70)), ('H', (-0.45, 0.80, 3.75))],
    'NH2NH2':  [('N', (0, 0, 2.00)), ('H', (-0.55, 0.82, 2.30)), ('H', (-0.55, -0.82, 2.30)),
                ('N', (0.25, 0, 3.42)), ('H', (1.25, 0, 3.62)), ('H', (-0.20, 0.0, 4.30))],
}
# formula of each adsorbate as (nN, nH) for the reference energies
ADS_NH = {k: (sum(s == 'N' for s, _ in v), sum(s == 'H' for s, _ in v)) for k, v in ADSORBATES.items()}


def add_adsorbate(sac, ads):
    """Place the adsorbate on top of the metal (last atom of the SAC). The fragment is
    rotated about z in 15-degree steps and the orientation that keeps it farthest from
    the substrate atoms is used (avoids clashes with puckered S atoms)."""
    tm = len(sac) - 1
    p = sac.positions[tm]
    frag = np.array([r for _, r in ADSORBATES[ads]], float)
    syms = [s for s, _ in ADSORBATES[ads]]
    best, best_d = None, -1
    for ang in np.radians(np.arange(0, 360, 15)):
        c, s = np.cos(ang), np.sin(ang)
        R = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        pos = p + frag @ R.T
        D = get_distances(pos, sac.positions[:tm], cell=sac.cell, pbc=sac.pbc)[1]   # adsorbate vs substrate
        if D.min() > best_d:
            best, best_d = pos, D.min()
    return sac.copy() + Atoms(syms, positions=best)


def gas(name):
    from ase.build import molecule
    m = molecule(name)
    m.cell = [15, 15.5, 16]; m.center(); m.pbc = True
    return m


def alpha_mn():
    # alpha-Mn, I-43m (217), a = 8.911 A, 58 atoms (conventional)
    return crystal(['Mn'] * 4, basis=[(0, 0, 0), (0.3179, 0.3179, 0.3179),
                                     (0.3571, 0.3571, 0.0347), (0.0896, 0.0896, 0.2819)],
                   spacegroup=217, cellpar=[8.911, 8.911, 8.911, 90, 90, 90], primitive_cell=True)


def bulk_metal(m):
    return alpha_mn() if m == 'Mn' else bulk(m)


def check(atoms, dmin=0.85):
    """Smallest interatomic distance must be > dmin (no overlapping atoms)."""
    D = atoms.get_all_distances(mic=True)
    np.fill_diagonal(D, 9)
    return D.min() > dmin, float(D.min())
