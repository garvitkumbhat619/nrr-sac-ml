"""
nrr_mlip.py - run NRR / HER energetics of single-atom catalysts with any ASE
calculator (Meta UMA via fairchem, MACE, ...).

Two stages
  1. run_*()   : relax structures, store RAW total energies in results.jsonl
                 (one line per structure, so a crashed Colab run can resume)
  2. analyse() : turn raw energies into dE, dG, limiting potentials, Ef

Definitions (same as Xu et al., Nano Research 2025)
  dE(*NxHy) = E(*NxHy) - E(*) - x/2 E(N2) - y/2 E(H2)                (Eq. 3)
  dG        = dE + dZPE - TdS     (computational hydrogen electrode, U = 0, pH = 0)
  U_L       = -max(dG of the proton-electron steps)
  Ef        = E(TM@support) - E(support) - E(bulk metal per atom)
"""
import os, json, time, shutil, tempfile
import numpy as np
from ase.io import read, write
from ase.optimize import LBFGS
from ase.vibrations import Vibrations
from ase.thermochemistry import HarmonicThermo

# ------------------------------------------------------------------ constants
T = 298.15
# gas-phase ZPE and T*S at 298 K, 1 bar (eV) - standard CHE values
GAS_ZPE_TS = {'H2': (0.27, 0.40), 'N2': (0.15, 0.59), 'NH3': (0.89, 0.60)}
# 1/2 N2 + 3/2 H2 -> NH3(g): experimental dG_f = -16.4 kJ/mol = -0.17 eV
DGF_NH3_EXP = -0.17
# UMA 'oc20' task predicts RPBE total energies on the OC20 reference;
# its gas references are E(H) = 1/2 E(H2), E(N) = 1/2 E(N2)
OC20_REFS = {'H': -3.477, 'N': -8.083}
NON_METALS = {'H', 'C', 'N', 'S', 'O', 'B', 'P'}

ADS_NH = {'bare': (0, 0), 'H': (0, 1), 'N2_end': (2, 0), 'N2_side': (2, 0),
          'NNH_end': (2, 1), 'NNH_side': (2, 1), 'NNH2': (2, 2), 'N': (1, 0),
          'NH': (1, 1), 'NH2': (1, 2), 'NH3': (1, 3), 'NHNH': (2, 2),
          'NHNH2': (2, 3), 'NH2NH2': (2, 4)}


# ------------------------------------------------------------------ helpers
def tm_index(atoms):
    idx = [i for i, s in enumerate(atoms.get_chemical_symbols()) if s not in NON_METALS]
    return idx[0] if idx else None


def ads_indices(atoms, n_substrate):
    return list(range(n_substrate, len(atoms)))


def relax(atoms, calc, fmax=0.05, steps=500, cell=False):
    atoms.calc = calc
    obj = atoms
    if cell:
        from ase.filters import FrechetCellFilter
        obj = FrechetCellFilter(atoms)
    opt = LBFGS(obj, logfile=None)
    conv = opt.run(fmax=fmax, steps=steps)
    return float(atoms.get_potential_energy()), int(opt.nsteps), bool(conv)


def site_atoms(atoms, n_sub):
    """Substrate atoms bonded to the metal in a structure: the nearest ones, keeping
    those within 0.6 A of the shortest metal-substrate distance (3 for a single
    vacancy, 4 for a divacancy)."""
    tm = n_sub - 1
    d = atoms.get_distances(tm, list(range(tm)), mic=True)
    order = np.argsort(d)[:4]
    return [int(k) for k in order if d[k] < d[order[0]] + 0.6]


def check_adsorbate(atoms, n_sub, ads, site0=None):
    """Is the metal still in its site, and did the adsorbate stay on the metal and intact?
    site0 = indices of the metal's neighbours in the starting structure."""
    tm = n_sub - 1
    ai = ads_indices(atoms, n_sub)
    sym = atoms.get_chemical_symbols()
    D = atoms.get_all_distances(mic=True)
    if site0 is None:
        site0 = site_atoms(atoms, n_sub)
    if sum(D[tm, k] < 2.9 for k in site0) < len(site0) - 1:
        return 'metal left the site'
    if ads == 'bare':
        return 'ok'
    heavy = [i for i in ai if sym[i] == 'N'] or ai          # anchor atoms
    d_tm = min(D[tm, i] for i in heavy)
    if d_tm > 2.6:
        return 'desorbed/moved'
    # H must sit on the metal (for *H) or on an adsorbate N
    for i in ai:
        if sym[i] != 'H':
            continue
        partner = min((j for j in range(len(atoms)) if j != i), key=lambda j: D[i, j])
        if ads == 'H' and partner != tm:
            return f'H moved to {sym[partner]}'
        if ads != 'H' and partner not in ai:
            return f'H moved to {sym[partner]}'
    n_N = [i for i in ai if sym[i] == 'N']
    if len(n_N) == 2 and D[n_N[0], n_N[1]] > 1.9:
        return 'N-N broken'
    return 'ok'


def vib_correction(atoms, calc, idx, T=T):
    """Harmonic ZPE and T*S of the adsorbate atoms (substrate frozen)."""
    if not idx:
        return 0.0, 0.0
    atoms = atoms.copy(); atoms.calc = calc
    d = tempfile.mkdtemp()
    try:
        vib = Vibrations(atoms, indices=idx, name=os.path.join(d, 'vib'), delta=0.01, nfree=2)
        vib.run()
        e = vib.get_energies()
    finally:
        shutil.rmtree(d, ignore_errors=True)
    e = np.where(np.abs(e.imag) > 1e-6, 0, e.real)
    e = np.clip(e, 0.0062, None)                    # floor soft/imaginary modes at 50 cm-1
    th = HarmonicThermo(vib_energies=e)
    zpe = 0.5 * e.sum()
    ts = T * th.get_entropy(T, verbose=False)
    return float(zpe), float(ts)


def _done(path):
    if not os.path.exists(path):
        return set()
    return {(r['system'], r['kind']) for r in map(json.loads, open(path))}


def _save(path, row):
    with open(path, 'a') as f:
        f.write(json.dumps(row) + '\n')


# ------------------------------------------------------------------ stage 1
def run_sac(sac, struct_dir, ads_list, calc, out_dir, d3=None, do_vib=True,
            fmax=0.05, steps=500, strip_check=True, rebuild_ads=False):
    """Relax the bare SAC and each adsorbate structure of one catalyst.
    rebuild_ads=True: relax the bare SAC first, then build every adsorbate on the
    *relaxed* bare geometry with sac_builder.add_adsorbate (instead of reading the
    shipped adsorbate files). Recommended when the shipped files are not pre-relaxed."""
    os.makedirs(f'{out_dir}/relaxed/{sac}', exist_ok=True)
    res = f'{out_dir}/results.jsonl'
    done = _done(res)
    bare = read(f'{struct_dir}/{sac}/bare.vasp', do_not_split_by_at_sign=True)
    n_sub = len(bare)
    site0 = site_atoms(bare, n_sub)
    relaxed_bare = f'{out_dir}/relaxed/{sac}/bare.extxyz'
    if rebuild_ads and (sac, 'bare') in done and not os.path.exists(relaxed_bare):
        b = bare.copy(); relax(b, calc, fmax, steps); write(relaxed_bare, b)   # results restored without geometries
    for ads in ['bare'] + [a for a in ads_list if a != 'bare']:
        if (sac, ads) in done:
            continue
        if ads == 'bare':
            a = bare.copy()
        elif rebuild_ads:
            from sac_builder import add_adsorbate, orient
            a = add_adsorbate(orient(read(relaxed_bare), n_sub), ads)
        else:
            a = read(f'{struct_dir}/{sac}/{ads}.vasp', do_not_split_by_at_sign=True)
        t = time.time()
        E, nst, conv = relax(a, calc, fmax, steps)
        row = dict(system=sac, kind=ads, E=E, steps=nst, converged=conv,
                   status=check_adsorbate(a, n_sub, ads, site0), n_sub=n_sub)
        if d3 is not None:
            b = a.copy(); b.calc = d3; row['E_d3'] = float(b.get_potential_energy())
        if do_vib and ads != 'bare':
            row['zpe'], row['ts'] = vib_correction(a, calc, ads_indices(a, n_sub))
        row['sec'] = round(time.time() - t, 1)
        write(f'{out_dir}/relaxed/{sac}/{ads}.extxyz', a)
        _save(res, row)
        # strip-and-re-relax: is there a lower-energy bare SAC hiding?
        if strip_check and ads == 'H' and (sac, 'bare_from_H') not in done:
            b = a[:n_sub]
            Eb, nst, conv = relax(b, calc, fmax, steps)
            r2 = dict(system=sac, kind='bare_from_H', E=Eb, steps=nst, converged=conv,
                      status=check_adsorbate(b, n_sub, 'bare', site0), n_sub=n_sub)
            if d3 is not None:
                c = b.copy(); c.calc = d3; r2['E_d3'] = float(c.get_potential_energy())
            _save(res, r2)
            write(f'{out_dir}/relaxed/{sac}/bare_from_H.extxyz', b)


def export_relaxed_poscars(out_dir, dest, systems=None):
    """Write every relaxed structure as a VASP POSCAR (good DFT starting geometries)."""
    import glob
    n = 0
    for f in glob.glob(f'{out_dir}/relaxed/*/*.extxyz'):
        sysname, kind = f.split('/')[-2], os.path.basename(f)[:-7]
        if systems is not None and sysname not in systems:
            continue
        os.makedirs(f'{dest}/{sysname}', exist_ok=True)
        write(f'{dest}/{sysname}/{kind}.vasp', read(f), format='vasp', direct=True)
        n += 1
    return n


def run_simple(kind, name, path, calc, out_dir, d3=None, cell=False, fmax=0.05, steps=500, vib=False):
    """Supports, gas molecules and bulk metals (kind = 'support' / 'gas' / 'bulk')."""
    os.makedirs(out_dir, exist_ok=True)
    res = f'{out_dir}/results.jsonl'
    if (name, kind) in _done(res):
        return
    a = read(path, do_not_split_by_at_sign=True)
    E, nst, conv = relax(a, calc, fmax, steps, cell=cell)
    row = dict(system=name, kind=kind, E=E, steps=nst, converged=conv, natoms=len(a), status='ok')
    if d3 is not None:
        b = a.copy(); b.calc = d3; row['E_d3'] = float(b.get_potential_energy())
    _save(res, row)
    os.makedirs(f'{out_dir}/relaxed/{kind}', exist_ok=True)
    write(f'{out_dir}/relaxed/{kind}/{name}.extxyz', a)


# ------------------------------------------------------------------ stage 2
def analyse(results_path, refs='computed', use_d3=False, nh3='experimental', use_strip=True):
    """refs = 'computed' (use relaxed N2/H2/NH3 from the same model) or 'oc20'.
    Returns (per-structure table, per-SAC table) as pandas DataFrames."""
    import pandas as pd
    df = pd.DataFrame([json.loads(l) for l in open(results_path)])
    if 'E_d3' not in df:
        df['E_d3'] = 0.0
    df['Etot'] = df.E + (df.E_d3.fillna(0) if use_d3 else 0)
    get = lambda s, k: df[(df.system == s) & (df.kind == k)].Etot
    # gas references
    if refs == 'oc20':
        EH2, EN2 = 2 * OC20_REFS['H'], 2 * OC20_REFS['N']
        ENH3 = None
    else:
        EH2, EN2 = get('H2', 'gas').iloc[0], get('N2', 'gas').iloc[0]
        ENH3 = get('NH3', 'gas').iloc[0] if len(get('NH3', 'gas')) else None
    G = lambda E, g: E + GAS_ZPE_TS[g][0] - GAS_ZPE_TS[g][1]
    GH2, GN2 = G(EH2, 'H2'), G(EN2, 'N2')
    if nh3 == 'experimental' or ENH3 is None:
        g_nh3 = DGF_NH3_EXP                                  # relative to 1/2 N2 + 3/2 H2
    else:
        g_nh3 = G(ENH3, 'NH3') - 0.5 * GN2 - 1.5 * GH2
    # per-structure
    ads = df[df.kind.isin(ADS_NH.keys()) & (df.kind != 'bare')].copy()
    kinds = ['bare', 'bare_from_H'] if use_strip else ['bare']
    ok_bare = df.kind.isin(kinds) & ((df.kind == 'bare') | (df.status == 'ok'))   # strip result only if site intact
    bare = df[ok_bare].groupby('system').Etot.min()
    bare_status = df[df.kind == 'bare'].groupby('system').status.first()
    ads['E_bare'] = ads.system.map(bare)
    nN = ads.kind.map(lambda k: ADS_NH[k][0]); nH = ads.kind.map(lambda k: ADS_NH[k][1])
    ads['dE'] = ads.Etot - ads.E_bare - nN / 2 * EN2 - nH / 2 * EH2
    corr_gas = nN / 2 * (GAS_ZPE_TS['N2'][0] - GAS_ZPE_TS['N2'][1]) + nH / 2 * (GAS_ZPE_TS['H2'][0] - GAS_ZPE_TS['H2'][1])
    ads['dG'] = ads.dE + ads.get('zpe', 0) - ads.get('ts', 0) - corr_gas
    # per-SAC
    rows = []
    for sac, d in ads.groupby('system'):
        g = dict(zip(d.kind, d.dG)); e = dict(zip(d.kind, d.dE)); st = dict(zip(d.kind, d.status))
        r = dict(SAC=sac, Metal=sac.split('@')[0], Support=sac.split('@')[1])
        for k in ADS_NH:
            if k in e:
                r[f'dE_{k}'] = e[k]; r[f'dG_{k}'] = g[k]; r[f'status_{k}'] = st[k]
        r['status_bare'] = bare_status.get(sac, 'missing')
        r['bare_lowered_by_strip'] = float(df[(df.system == sac) & (df.kind == 'bare')].Etot.min() - bare[sac])
        if 'H' in g:
            r['dG_H*'] = g['H']
        # Xu-style descriptors
        if 'N2_end' in g and 'NNH_end' in g:
            r['dG_N2_to_NNH_end'] = g['NNH_end'] - g['N2_end']
        if 'N2_side' in g and 'NNH_side' in g:
            r['dG_N2_to_NNH_side'] = g['NNH_side'] - g['N2_side']
        if 'NH2' in g and 'NH3' in g:
            r['dG_NH2_to_NH3'] = g['NH3'] - g['NH2']
        # full pathways
        paths = {'distal': ['N2_end', 'NNH_end', 'NNH2', 'N', 'NH', 'NH2', 'NH3'],
                 'alternating': ['N2_end', 'NNH_end', 'NHNH', 'NHNH2', 'NH2NH2', 'NH2', 'NH3']}
        for pname, seq in paths.items():
            if not all(k in g for k in seq):
                continue
            # free energy of each state (relative to * + N2 + 3 H2), counting released NH3
            nh3_out = {'distal': [0, 0, 0, 1, 1, 1, 1], 'alternating': [0, 0, 0, 0, 0, 1, 1]}[pname]
            states = [0.0] + [g[k] + n * g_nh3 for k, n in zip(seq, nh3_out)] + [2 * g_nh3]
            steps = np.diff(states)
            pcet = steps[1:-1]                      # skip N2 adsorption and final NH3 desorption
            r[f'UL_{pname}'] = -float(pcet.max())
            # trustworthy only if every intermediate stayed bound and intact
            r[f'path_ok_{pname}'] = all(st[k] == 'ok' for k in seq) and r['status_bare'] == 'ok'
            r[f'PDS_{pname}'] = f'{(["*"] + seq)[1 + int(pcet.argmax())]}->{(seq + ["*"])[1 + int(pcet.argmax())]}'
            r[f'dG_NH3_desorption_{pname}'] = float(steps[-1])
        rows.append(r)
    sac_df = pd.DataFrame(rows)
    # formation energy vs bulk metal
    sup = df[df.kind == 'support'].set_index('system').Etot
    blk = df[df.kind == 'bulk'].set_index('system')
    mu = (blk.Etot / blk.natoms) if len(blk) else {}
    def ef(r):
        try:
            return bare[r.SAC] - sup[f"support_{r.Support}"] - mu[r.Metal]
        except Exception:
            return np.nan
    if len(sac_df):
        sac_df['Ef_eV'] = sac_df.apply(ef, axis=1)
    return ads, sac_df
