# SAC_broadened_package: 280 new single-atom catalysts (N/C divacancy and single vacancy)

There are 28 metals × 10 new coordination environments on 5×5 graphene (cell c = 20 Å), the same metals and settings as `SAC_UMA_package`.

| family | supports | coordination |
|---|---|---|
| A: N/C on divacancy | N3C1, N2C2-PEN, N2C2-HEX, N2C2-OPP, N1C3, C4 | 4 (2 C removed) |
| C: single vacancy | SV-N3, SV-N2C1, SV-N1C2, SV-C3 | 3 (1 C removed) |

"C" sites are the original dangling carbons. PEN/HEX/OPP use the same site labels as Xu's S2N2 isomers (a1,b1 / a1,a2 / a1,b2).

## Contents

* `structures/<TM@support>/bare.vasp` is the starting geometry, **not pre-relaxed**. In a single vacancy the metal starts 1.3 Å above the sheet.
* `structures/<TM@support>/<adsorbate>.vasp` has the 13 intermediates built on that starting geometry. These are for viewing or DFT. The notebook instead rebuilds them on the UMA-relaxed bare catalyst (`rebuild_ads=True`).
* `supports/`, `bulk/` and `gas/` hold the reference structures.
* `manifest.csv` lists every file, with its family and tier (`1_core` is the bare catalyst plus *H, *N2 end-on, *NNH end-on and *NH2).
* `dft_request_candidates.csv` lists 38 catalysts suggested for DFT:
  * 30 new-environment catalysts (3 per support, covering all 28 metals), for fine-tuning UMA.
  * 8 of Xu's S/N catalysts, to check first that the DFT setup reproduces Xu.
  * Each with 5 intermediates, which makes 190 relaxations.
* `UMA_broadened_Colab.ipynb` is the notebook to run, and `sac_builder.py`, `nrr_mlip.py` and `validate.py` are the code.

## Why the numbers from this run are only rough

Zero-shot UMA was checked against Xu's DFT on 23 catalysts. For the adsorption energies of *N2, *NNH and *NH2 it was no better
than guessing the mean, with MAE 0.57–0.85 eV and r ≤ 0.6. For ΔG*H (r 0.72) and Ef (r 0.78) it gives trends only.

So use this run for:

1. relaxed geometries as DFT starting points;
2. rough Ef and ΔG*H trends, labelled "UMA zero-shot";
3. the structures a fine-tuned model will be run on later.

## Suggested DFT settings

These match Xu et al. 2025, so new data can be merged with theirs:

* VASP, PAW, PBE + DFT-D3, spin-polarised
* ENCUT 500 eV, 2×2×1 k-points for relaxation
* EDIFF 1e-4 eV, forces below 0.02 eV/Å
* 15 Å vacuum
* For fine-tuning, keep every ionic step of each relaxation (OUTCAR / vasprun.xml), not only the final energy. Each relaxation then gives 20–100 training frames with energies and forces.
