"""One worker process: runs its share of the catalysts on one GPU until the jobs are
done or the time budget is used up.  usage: python kaggle_worker.py CONFIG.json WORKER NWORKERS"""
import sys, os, json, time, warnings
warnings.filterwarnings('ignore')
cfg = json.load(open(sys.argv[1]))
w, nw = int(sys.argv[2]), int(sys.argv[3])
sys.path.insert(0, cfg['bundle'])
import nrr_mlip as nm

log = open(os.path.join(cfg['run_dir'], f'worker{w}.log'), 'a')
def say(msg):
    log.write(time.strftime('%H:%M:%S ') + msg + '\n'); log.flush()

import torch
dev = 'cuda' if torch.cuda.is_available() else 'cpu'
if dev == 'cpu':
    torch.set_num_threads(max(1, (os.cpu_count() or 2) // nw))
if cfg['model'] == 'uma':
    from fairchem.core import pretrained_mlip, FAIRChemCalculator
    predictor = pretrained_mlip.get_predict_unit(cfg['uma_model'], device=dev)
    calc = FAIRChemCalculator(predictor, task_name=cfg['task'])
else:
    from mace.calculators import mace_mp
    calc = mace_mp(model='medium-mpa-0', default_dtype='float32', device=dev)
say(f'model loaded on {dev}')

deadline = cfg['deadline']
for job in cfg['jobs']:
    out = os.path.join(cfg['run_dir'], f"{job['name']}_w{w}")
    if job['type'] == 'refs':
        if w != 0:
            continue
        for r in job['items']:
            if time.time() > deadline:
                say('time budget reached'); sys.exit(0)
            nm.run_simple(r['kind'], r['system'], r['path'], calc, out,
                          cell=(r['kind'] == 'bulk'), fmax=0.02 if r['kind'] == 'bulk' else 0.05)
        say(f"{job['label']}: done")
        continue
    mine = [s for i, s in enumerate(job['sacs']) if i % nw == w]
    t0 = time.time()
    for k, sac in enumerate(mine):
        if time.time() > deadline:
            say(f"time budget reached during {job['label']} ({k}/{len(mine)} of my catalysts)"); sys.exit(0)
        nm.run_sac(sac, job['struct_dir'], job['ads'], calc, out, rebuild_ads=job['rebuild'])
        if (k + 1) % 5 == 0 or k + 1 == len(mine):
            el = (time.time() - t0) / 60
            say(f"{job['label']}: {k+1}/{len(mine)} catalysts, {el:.0f} min")
    say(f"{job['label']}: done")
say('all jobs done')
